<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('listaProcs', 'ProcessoController@listaProcs');

Route::get('editaProc/{id}', 'ProcessoController@editaProc');

Route::post('updateProc/{id}', 'ProcessoController@updateProc');

Route::post('excluiProc/{id}', 'ProcessoController@excluiProc');

Route::get('listaDocs/{id}','DocController@listaDocs');

Route::get('listaPess','PessoaController@listaPess');

Route::get('listaPessDocs/{id}','PessoaController@listaPessDocs');

Route::get('criaPess','PessoaController@criaPess');

Route::get('editaPess/{id}', 'PessoaController@editaPess');

Route::post('savePess','PessoaController@savePess');

Route::get('criaDoc/{id}','DocController@criaDoc');

Route::get('editaDoc/{id}','DocController@editaDoc');

Route::post('updateDoc/{id}', 'DocController@updateDoc');

Route::get('criaDocDeProc/{id}','ProcessoController@criaDocDeProc');

Route::post('saveDoc','DocController@saveDoc');

Route::post('saveDocDeProc','DocController@saveDocDeProc');

Route::get('/', function () {
    return view('welcome');
});

