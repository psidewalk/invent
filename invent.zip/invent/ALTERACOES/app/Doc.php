<?php

namespace Inventario;

use Illuminate\Database\Eloquent\Model;

class Doc extends Model
{
    protected $fillable = ['processo_id','codigo','titulo','dtEntrada','dtEntrega','custo','texto'];

    public function processo()  {

        return $this->belongsTo('Inventario\Processo');
    }

    public function pessoas()  {
        
        return $this->belongsToMany('Inventario\Pessoa');
    }

}