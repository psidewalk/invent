<?php

namespace Inventario;

use Illuminate\Database\Eloquent\Model;

class Processo extends Model
{
    protected $fillable = ['codigo','nome','texto'];

    public function docs()  {

        return $this->hasMany('Inventario\Doc');
        
    } 
    
    
}
