<?php

namespace Inventario;

use Illuminate\Database\Eloquent\Model;

class Pessoa extends Model
{
    protected $fillable = ['codigo','nome','cpf','dtNasc','ident',
                           'nome_pai','nome_mae','benefINSS','benefPrvBan','dtFalec','texto'];

    public function docs()  {

        return $this->belongsToMany('Inventario\Doc');

    }
}
