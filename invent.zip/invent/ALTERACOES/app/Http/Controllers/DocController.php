<?php

namespace Inventario\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Inventario\Doc;
use Inventario\Processo;
use Inventario\Pessoa;

class DocController extends Controller
{
    private $doc;
    
    public function __construct(Doc $doc)
    {
        $this->doc = $doc;    
    }
    
    public function listaDocs($procId)
    {
        $docs = Doc::where('processo_id', $procId)->get();
        $procViewId = $procId;
        //return response()->json([$docs]);
        if ($docs->count() > 0)   {
            $docZero = $docs[0];
            return view('docs.listaDocs',compact('docs'),compact('docZero'));
        }            
            return view('docs.listaNoDocs','procViewId');   
    }

    public function criaDoc($procId) // $procId - codigo do processo advindo da lista de documentos
    {
        $this->processo = Processo::Find($procId);
        $idVai = $this->processo->id;
        $codVai = $this->processo->codigo;
        $nome = $this->processo->nome;
        $pessoas = Pessoa::all('nome','id');
        return view('docs.novodoc',compact('codVai','idVai','nome','pessoas'));
    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveDoc(Request $request)
    {
        //Usando o Eloquent 
        $this->doc = Doc::create($request->all());
        $this->doc->save();
        $this->doc->pessoas()->attach($request->input('idPess'));
        //return response()->json([$this->doc]);
        return redirect()->action('DocController@listaDocs');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editaDoc($id)
    {
        $doc = $this->doc->find($id);
        if (empty($doc)) {
            return "Esse doc não existe";
        }
        return view('docs/formedita')->with('d', $doc);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateDoc(Request $request, $id)
    {
        $this->doc = Doc::Find($id);
        $atualizou = $this->doc->update($request->all());
        if (!$atualizou) {
            return "Não consegui atualizar o banco. Verifique";
        }
        $docs = Doc::where('processo_id', $this->doc->processo->id)->get();
        $procViewId = $this->doc->processo->id;
        //return response()->json([$docs]);
        if ($docs->count() > 0)   {
            return view('docs.listaDocs',compact('docs'));
        }            
            return view('docs.listaNoDocs','procViewId');   

        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
