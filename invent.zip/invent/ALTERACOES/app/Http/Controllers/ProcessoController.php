<?php

namespace Inventario\Http\Controllers;

use Illuminate\Http\Request;
use Inventario\Processo;
use Inventario\Doc;

class ProcessoController extends Controller
{
    private $processo;

    public function __construct(Processo $processo)
    {
        $this->processo = $processo;    
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function listaProcs()
    {
        $processos = $this->processo->all();
        //return response()->json([$processos]);
        return view('processos.listaProcs',compact('processos'));
    }

    public function criaDocDeProc($procId)
    {
        $this->processo = Processo::Find($procId);
        $idVai = $this->processo->id;
        $codVai = $this->processo->codigo;
        $nome = $this->processo->nome;
        $pessoas = [];
        return view('docs.novodoc',compact('codVai','idVai','nome','pessoas'));
    }

    public function saveDocdeProc(Request $request)
    {
        //Usando o Eloquent 
        $this->doc = Doc::create($request->all());
        $this->doc->save();
        //return response()->json([$this->doc]);
        return redirect()->action('DocController@listaDocs');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editaProc($id)
    {
        $processo = $this->processo->find($id);
        if (empty($processo)) {
            return "Esse processo não existe";
        }
        return view('processos/formedita')->with('p', $processo);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateProc(Request $request, $id)
    {
        $atualizou = $this->processo->find($id)->update($request->all());
        if (!$atualizou) {
            return "Não consegui atualizar o banco. Verifique";
        }
        return redirect()->action('ProcessoController@listaProcs');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function excluiProc($id)
    {
        $excluiu = $this->processo->find($id)->delete();
        if (!$excluiu) {
            return "Não consegui excluir o processo. Verifique";
        }
        return redirect()->action('ProcessoController@listaProcs');
    }
}
