public function updateProc(Request $request, $id)
    {
        $processo = $this->processo->find($id);

        $processo->codigo = $request->codigo;
        $processo->nome = $request->nome;
        $processo->texto = $request->texto;

        $atualizou = $processo->save();

        dd($processo);
        dd($atualizou);

        if (!$atualizou) {
            return "Falha na atualização do banco";
        }
        return redirect()->action('ProcessoController@listaProcs');
    }
