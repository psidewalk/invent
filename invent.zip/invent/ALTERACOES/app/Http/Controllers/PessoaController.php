<?php

namespace Inventario\Http\Controllers;

use Illuminate\Http\Request;
use Inventario\Pessoa;

class PessoaController extends Controller
{
    private $pessoa;
    
    public function __construct(Pessoa $pessoa)
    {
        $this->pessoa = $pessoa;    
    }
    

    public function listaPess()
    {
        $pessoas = $this->pessoa->all();
        //if($pess->count()>0)
           return view('pess.listaPess',compact('pessoas'));
        //else
        //    return redirect()->action('PessoaController@create'); 
        //return response()->json([$pess]);
        //return response()->json([$pess->count()]);
    }

    public function criaPess()
    {
        return view('pess.novaPess');
    }

    public function listaPessDocs($id)
    {
        $pessoa = $this->pessoa->find($id);
        $docs = $pessoa->docs(); //todos os docs 'attachados' a essa pessoa ver Modelo Pessoa
        //$docZero = $docs[0];
        return response()->json($docs);
        //return view('docs.listaDocs',compact('docs',docZero));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function savePess(Request $request)
    {
        //Usando o Eloquent 
        $this->pessoa = Pessoa::create($request->all());
        $atualizou = $this->pessoa->save();
        if (!$atualizou) {
            return "Não consegui gravar no banco. Verifique";
        }
        return redirect()->action('PessoaController@listaPess');
    }

    public function editaPess($id)
    {
        $pessoa = $this->pessoa->find($id);
        if (empty($pessoa)) {
            return "Essa pessoa não existe";
        }
        return view('pess/formedita')->with('p', $pessoa);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatePess(Request $request, $id)
    {
        $atualizou = $this->pessoa->find($id)->update($request->all());
        if (!$atualizou) {
            return "Não consegui atualizar o banco. Verifique";
        }
        return redirect()->action('PessoaController@listaPess');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
