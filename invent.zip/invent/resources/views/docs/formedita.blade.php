@extends('layouts.app')

@section('content')

<div class="container">

	<div class="container-fluid">
		<br/>
		<h2>Editando o documento {{ $d->id }} do Inventário de {{ $d->processo->nome }}</h2>
		<br/>
		<form action="{{ url('updateDoc',$d->id) }}" method="post">

			<input type="hidden" name="_token" value="{{{ csrf_token() }}}">

			<div class="form-group">
				<label>Código</label>
				<input type="text" name="codigo" value="{{ $d->codigo }}" class="form-control">
			</div>
			<div class="form-group">
				<label>Titulo</label>
				<input type="text" name="titulo" value="{{ $d->titulo }}" class="form-control">
			</div>
			<div class="form-group">
				<label>Dt entrada</label>
				<input type="text" name="dtEntrada" value="{{ $d->dtEntrada }}" class="form-control">
			</div>
			<div class="form-group">
				<label>Dt entrega</label>
				<input type="text" name="dtEntrega" value="{{ $d->dtEntrega }}" class="form-control">
			</div>
			<div class="form-group">
				<label>Custo</label>
				<input type="text" name="custo" value="{{ $d->custo }}" class="form-control">
			</div>
			<div class="form-group">
				<label>Texto</label>
				<input type="text" name="texto" value="{{ $d->texto }}" class="form-control">
			</div>
			<div class="form-group">
				<label>Criado em</label>
				<input type="text" name="created_at" value="{{ $d->created_at }}" class="form-control">
			</div>
			<div class="form-group">
				<label>Atualizado em</label>
				<input type="text" name="updated_at" value="{{ $d->updated_at }}" class="form-control">
			</div>
			<button type="submit" class="btn btn-primary btn-block">Envia</button>

		</form>
	</div>
</div>

@stop