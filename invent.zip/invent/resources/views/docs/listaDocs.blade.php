@extends('layouts.app')

@section('content')

        </br>
		<h2>Documentos do Inventário de {{ $docZero->processo->nome }}</h2>
     	<br/>

        <table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
            <thead>
                <th><a href="/docs">Numero do Processo</a></th>
                <th><a href="/docs">Código do Doc</a></th>
                <th><a href="/docs/classdata">Titulo do Doc</a></th>
                <th>Data da Entrada</th>
                <th>Data da Entrega</th>
                <th>Custo</th>
                <th>Observações</th>
                <th>Criado em</th>
                <th>Atualizado em</th>
                <th>Editar</th>
                <th>Excluir</th>
            </thead>
            <tbody>
            @if(!empty($docs))
                @foreach ($docs as $d)
                    <!-- o foreach do blade  -->
                    <tr align="center">
                        <td>{{ $d->processo->codigo }}</td>
                        <td>{{ $d->codigo }}</td>
                        <td>{{ $d->titulo }}</td>
                        <td>{{ $d->dtEntrada }}</td>
                        <td>{{ $d->dtEntrega}}</td>
                        <td>{{ $d->custo }}</td>
                        <td>{{ $d->texto }}</td>
                        <td>{{ $d->created_at }}</td>
                        <td>{{ $d->updated_at }}</td>
                        <!--<td align="right">{{ $d->valor }}</td> -->
                        <td><a href="{{ url('editaDoc',$d->id) }}"><span class="glyphicon glyphicon-search"></a></td>
                        <td><a href="{{ url('excluiDoc',$d->id) }}"><span class="glyphicon glyphicon-trash"></span></a></td>
                    </tr>
                @endforeach
            @endif
        </table>
        <a class="btn btn-danger" id="butListDocs" href="{{ url('criaDoc',$d->processo->id) }}" role="button">Novo Documento</a>
<!-- <div class="alert alert-success">
    <strong>Operação bem-sucedida !</strong>
</div>
-->

@endsection