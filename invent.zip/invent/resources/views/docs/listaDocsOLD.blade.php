@extends('layouts.app')

@section('content')

<!--
<div class="container-fluid">
    <div class="navbar-right">
        <form class="form-search form form-inline" method="get" action="/docs/pesqdata">
            {{csrf_field()}}
            <input type="text" name="pesquisar" placeholder= "Ano-Mes-Dia" class="form-control calend">
            <input type="submit" value="Selecionar" class="btn btn-danger">
        </form>
    </div>
    <div class="navbar-left">
        <form class="form-search form form-inline" method="get" action="/docs/calcdif">
            {{csrf_field()}}
            <input type="text" name="dtini"   placeholder= "A-M-D inicial" class="form-control calend">
            <input type="text" name="dtfim"   placeholder= "A-M-D final" class="form-control calend">
            <input type="text" name="tipo"    placeholder="" class="form-control">
            <input type="submit" value="Calcular" class="btn btn-danger">
        </form>
            @if(!empty($dif))
                {{ $dif }}
            @endif
        </form>
    </div>
</div>
-->

@if(empty($docs))

<div class="alert alert-danger">
    Voce ainda não cadastrou nenhum documento.
</div>

@else
<br/>
<table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
    <thead>
    <th style="text-align: center"><a href="/docs">Numero do Processo</a></th>
    <th style="text-align: center"><a href="/docs">Código do Doc</a></th>
    <th style="text-align: center"><a href="/docs/classdata">Titulo do Doc</a></th>
    <th style="text-align: center">Data da Entrada</th>
    <th style="text-align: center">Data da Entrega</th>
    <th style="text-align: center">Custo</th>
    <th style="text-align: center">Observações</th>
    <th style="text-align: center">Criado em</th>
    <th style="text-align: center">Atualizado em</th>
    <th style="text-align: center">Editar</th>
    <th style="text-align: center">Excluir</th>
</thead>
<tbody>
    @foreach ($docs as $d)    <!-- o foreach do blade  -->
    <tr align="center">
        <td>{{ $d->processo->codigo }}</td>
        <td>{{ $d->codigo }}</td>
        <td>{{ $d->titulo }}</td>
        <td>{{ $d->dtEntrada }}</td>
        <td>{{ $d->dtEntrega}}</td>
        <td>{{ $d->custo }}</td>
        <td>{{ $d->texto }}</td>
        <td>{{ $d->created_at }}</td>
        <td>{{ $d->updated_at }}</td>
        <!--<td align="right">{{ $d->valor }}</td> -->
        <td><a href="{{ url('editaDoc',$d->id) }}"><span class="glyphicon glyphicon-search"></a></td>
        <td><a href="{{ url('excluiDoc',$d->id) }}"><span class="glyphicon glyphicon-trash"></span></a></td>
    </tr>
    @endforeach
    <!--
    -->
</table>
    <a class="btn btn-danger" id="butListDocs" href="{{ url('criaDoc',$d->processo->id) }}"
       role="button">Novo Documento</a>
@endif
<!-- <div class="alert alert-success">
    <strong>Operação bem-sucedida !</strong>
</div>
-->

@endsection
