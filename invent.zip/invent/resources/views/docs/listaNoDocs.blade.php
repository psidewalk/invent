@extends('layouts.app')

@section('content')

<br/>
<table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
	<thead>
		<th style="text-align: center"><a href="/docs">Numero do Processo</a></th>
		<th style="text-align: center"><a href="/docs">Código do Doc</a></th>
		<th style="text-align: center"><a href="/docs/classdata">Titulo do Doc</a></th>
		<th style="text-align: center">Data da Entrada</th>
		<th style="text-align: center">Data da Entrega</th>
		<th style="text-align: center">Custo</th>
		<th style="text-align: center">Observações</th>
		<th style="text-align: center">Criado em</th>
		<th style="text-align: center">Atualizado em</th>
		<th style="text-align: center">Editar</th>
		<th style="text-align: center">Excluir</th>
	</thead>
	<tbody>
</table>
<a class="btn btn-danger" id="butListDocs" href="{{ url('criaDoc',$procViewId) }}" role="button">Novo Documento</a>

@endsection