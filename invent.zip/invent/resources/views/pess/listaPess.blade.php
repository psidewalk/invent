@extends('layouts.app')

@section('content')

<!--
<div class="container-fluid">
    <div class="navbar-right">
        <form class="form-search form form-inline" method="get" action="/pess/pesqdata">
            {{csrf_field()}}
            <input type="text" name="pesquisar" placeholder= "Ano-Mes-Dia" class="form-control calend">
            <input type="submit" value="Selecionar" class="btn btn-danger">
        </form>
    </div>
    <div class="navbar-left">
        <form class="form-search form form-inline" method="get" action="/pess/calcdif">
            {{csrf_field()}}
            <input type="text" name="dtini"   placeholder= "A-M-D inicial" class="form-control calend">
            <input type="text" name="dtfim"   placeholder= "A-M-D final" class="form-control calend">
            <input type="text" name="tipo"    placeholder="" class="form-control">
            <input type="submit" value="Calcular" class="btn btn-danger">
        </form>
            @if(!empty($pesif))
                {{ $pesif }}
            @endif
        </form>
    </div>
</div>
-->

@if(empty($pessoas))

<div class="alert alert-danger">
    Voce ainda não cadastrou nenhuma Pessoa
</div>

@else
<br/>
<table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
    <thead>
    <!-- <th style="text-align: center"><a href="#">Código</a></th> por enquanto, fora--> 
    <th><a href="#">Docs</a></th>
    <th><a href="#">Nome da Pessoa</a></th>
    <th><a href="#">CPF</a></th>
    <th>Data Nasc</th>
    <th>Identidade</th>
    <th>Nome do Pai</th>
    <th>Nome da Mãe</th>
    <th>N.Benef.INSS</th>
    <th>N.Benef.PrvBnrj</th>
    <th>Data Falec.</th>
    <th>Observações</th>
    <th>Editar</th>
    <th>Excluir</th>
</thead>
<tbody>
    @foreach ($pessoas as $p)    <!-- o foreach do blade  -->
    <tr align="center">
        <td><a href="{{ url('listaPessDocs',$p->id) }}"><span class="glyphicon glyphicon-trash"></span></a></td>
        <!-- <td>{{ $p->codigo }}</td> por enquanto está fora -->
        <td>{{ $p->nome }}</td>
        <td>{{ $p->cpf }}</td>
        <td>{{ $p->dtNasc }}</td>
        <td>{{ $p->ident }}</td>
        <td>{{ $p->nome_pai }}</td>
        <td>{{ $p->nome_mae }}</td>
        <td>{{ $p->benefINSS }}</td>
        <td>{{ $p->benefPrvBan }}</td>
        <td>{{ $p->dtFalec }}</td>
        <td>{{ $p->texto }}</td>
        <td><a href="{{ url('editaPess',$p->id) }}"><span class="glyphicon glyphicon-search"></a></td>
        <td><a href="{{ url('excluiPess',$p->id) }}"><span class="glyphicon glyphicon-trash"></span></a></td>
    </tr>
    @endforeach
    <!--
    -->
</table>
    <!-- <a class="btn btn-danger" id="butListDocs" href="{{ url('criaPess') }}" role="button">Nova Pessoa</a> -->
@endif
<!-- <div class="alert alert-success">
    <strong>Operação bem-sucedida !</strong>
</div>
-->

@endsection
