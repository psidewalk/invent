@extends('layouts.app')

@section('content')

<!--
<div class="container-fluid">
    <div class="navbar-right">
        <form class="form-search form form-inline" method="get" action="/processos/pesqdata">
            {{csrf_field()}}
            <input type="text" name="pesquisar" placeholder= "Ano-Mes-Dia" class="form-control calend">
            <input type="submit" value="Selecionar" class="btn btn-danger">
        </form>
    </div>
    <div class="navbar-left">
        <form class="form-search form form-inline" method="get" action="/processos/calcdif">
            {{csrf_field()}}
            <input type="text" name="dtini"   placeholder= "A-M-D inicial" class="form-control calend">
            <input type="text" name="dtfim"   placeholder= "A-M-D final" class="form-control calend">
            <input type="text" name="tipo"    placeholder="" class="form-control">
            <input type="submit" value="Calcular" class="btn btn-danger">
        </form>
            @if(!empty($dif))
                {{ $dif }}
            @endif
        </form>
    </div>
</div>
-->

@if(empty($processos))

<div class="alert alert-danger">
    Voce ainda não cadastrou nenhum processo.
</div>

@else
<br/>
<table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
    <thead>
    <th style="text-align: center"><a href="/processos">Numero do Processo</a></th>
    <th style="text-align: center"><a href="/processos/classdata">Inventario de</a></th>
    <th style="text-align: center">Observações</th>
    <th style="text-align: center">Criado em</th>
    <th style="text-align: center">Atualizado em</th>
    <th style="text-align: center">Editar</th>
    <th style="text-align: center">Excluir</th>
</thead>
<tbody>
    @foreach ($processos as $p)    <!-- o foreach do blade  -->
    <tr align="center">
        <td><a id="docListaDocs" href="{{ url('listaDocs',$p->id) }}">{{ $p->codigo }}</a></td>
        <td>{{ $p->nome }}</td>
        <td>{{ $p->texto }}</td>
        <td>{{ $p->created_at }}</td>
        <td>{{ $p->updated_at }}</td>
        <!--<td align="right">{{ $p->valor }}</td> -->
        <td><a href="{{ url('editaProc',$p->id) }}"><span class="glyphicon glyphicon-search"></a></td>
        <td><a href="{{ url('excluiProc',$p->id) }}"><span class="glyphicon glyphicon-trash"></span></a></td>
    </tr>
    @endforeach
    <!--
    -->
</table>
<!--
    <a class="btn btn-danger" id="butListDocs" href="{{ url('criaDocDeProc',$p->id) }}"
       role="button">Novo Documento</a>
@endif
-->
<!-- <div class="alert alert-success">
    <strong>Operação bem-sucedida !</strong>
</div>
-->

@endsection
