<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="container-fluid">

			<h2>Nova Pessoa</h2>

			<form action = "<?php echo e(url('savePess')); ?>" method="post">
			
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
					
				<div class="form-group">
					<label>Código da Pessoa</label>
					<input name="codigo" class="form-control">
				</div>
				<div class="form-group">
					<label>Nome</label>
					<input name="nome" class="form-control">
				</div>
				<div class="form-group">
					<label>CPF</label>
					<input name="cpf" class="form-control calend">
				</div>
				<div class="form-group">
					<label>Data de Nasc.</label>
					<input name="dtNasc" class="form-control calend">
				</div>
				<div class="form-group">
					<label>Identidade</label>
					<input name="ident" class="form-control">
				</div>
				<div class="form-group">
					<label>Nome do Pai</label>
					<input name="nome_pai" class="form-control">
				</div>
				<div class="form-group">
					<label>Nome da Mãe</label>
					<input name="nome_mae" class="form-control">
				</div>
				<div class="form-group">
					<label>Benef. INSS</label>
					<input name="benefINSS" class="form-control">
				</div>
				<div class="form-group">
					<label>Benef. Pre-Bnrj</label>
					<input name="benefPrvBan" class="form-control">
				</div>
				<div class="form-group">
					<label>Data de Falec.</label>
					<input name="dtFalec" class="form-control">
				</div>
				<div class="form-group">
					<label>Observações</label>
					<input name="texto" class="form-control">
				</div>
						
				<button type="submit" class="btn btn-primary btn-block">Envia</button>
				
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>