<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="container-fluid">
		<br/>
		<h2>Editando o processo <?php echo e($p->id); ?></h2>
		<br/>
		<form action = "/updateProc/<?php echo e($p->id); ?>" method="post">
		
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				
			<div class="form-group">
				<label>Número do Processo</label>
				<input type="text" name="codigo" value = "<?php echo e($p->codigo); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Inventario de</label>
				<input type="text" name="nome" value = "<?php echo e($p->nome); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Observações</label>
				<input type="text" name="texto" value = "<?php echo e($p->texto); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Criado em</label>
				<input type="text" name="created_at" value = "<?php echo e($p->created_at); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Atualizado em</label>
				<input type="text" name="updated_at" value = "<?php echo e($p->updated_at); ?>" class="form-control">
			</div>
			<button type="submit" class="btn btn-primary btn-block">Envia</button>
			
		</form>
	</div>
</div>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>