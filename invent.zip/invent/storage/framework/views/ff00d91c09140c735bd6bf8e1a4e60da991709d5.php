<?php $__env->startSection('content'); ?>

        </br>
		<h2>Documentos do Inventário de <?php echo e($docs[0]->processo->nome); ?></h2>
     	<br/>

        <table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
            <thead>
                <th><a href="/docs">Numero do Processo</a></th>
                <th><a href="/docs">Código do Doc</a></th>
                <th><a href="/docs/classdata">Titulo do Doc</a></th>
                <th>Data da Entrada</th>
                <th>Data da Entrega</th>
                <th>Custo</th>
                <th>Observações</th>
                <th>Criado em</th>
                <th>Atualizado em</th>
                <th>Editar</th>
                <th>Excluir</th>
            </thead>
            <tbody>
            <?php if(!empty($docs)): ?>
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- o foreach do blade  -->
                    <tr align="center">
                        <td><?php echo e($d->processo->codigo); ?></td>
                        <td><?php echo e($d->codigo); ?></td>
                        <td><?php echo e($d->titulo); ?></td>
                        <td><?php echo e($d->dtEntrada); ?></td>
                        <td><?php echo e($d->dtEntrega); ?></td>
                        <td><?php echo e($d->custo); ?></td>
                        <td><?php echo e($d->texto); ?></td>
                        <td><?php echo e($d->created_at); ?></td>
                        <td><?php echo e($d->updated_at); ?></td>
                        <!--<td align="right"><?php echo e($d->valor); ?></td> -->
                        <td><a href="<?php echo e(url('editaDoc',$d->id)); ?>"><span class="glyphicon glyphicon-search"></a></td>
                        <td><a href="<?php echo e(url('excluiDoc',$d->id)); ?>"><span class="glyphicon glyphicon-trash"></span></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>
        <a class="btn btn-danger" id="butListDocs" href="<?php echo e(url('criaDoc',$d->processo->id)); ?>" role="button">Novo Documento</a>
<!-- <div class="alert alert-success">
    <strong>Operação bem-sucedida !</strong>
</div>
-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>