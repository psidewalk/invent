<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="container-fluid">

		<h2>Editando o registro de <?php echo e($p->nome); ?></h2>
        <br/>
		<form action="<?php echo e(url('updatePess',$p->id)); ?>" method="post">

			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="row">
                    <label class="afasta">CPF</label>
                    <input type="text" name="cpf" value="<?php echo e($p->cpf); ?>" class="cpf">
                    <label class="afasta">Nome</label>
                    <input type="text" name="nome" value="<?php echo e($p->nome); ?>" class="nomepess">
			</div>
            </br/>
			<div class="form-group">
				<label>Dt Nasc</label>
				<input type="text" name="dtNasc" value="<?php echo e($p->dtNasc); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Identidade</label>
				<input type="text" name="ident" value="<?php echo e($p->ident); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Nome do Pai</label>
				<input type="text" name="nome_pai" value="<?php echo e($p->nome_pai); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Nome da Mãe</label>
				<input type="text" name="nome_mae" value="<?php echo e($p->nome_mae); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>N.Benef.INSS</label>
				<input type="text" name="benefINSS" value="<?php echo e($p->benefINSS); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>N.Benef.PrvBnrj</label>
				<input type="text" name="benefPrvBan" value="<?php echo e($p->benefPrvBan); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Data Falec.</label>
				<input type="text" name="dtFalec" value="<?php echo e($p->dtFalec); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Observações</label>
				<input type="text" name="texto" value="<?php echo e($p->texto); ?>" class="form-control">
			</div>
            <div>
				<label>Criado em</label>
				<input type="text" name="created_at" value="<?php echo e($p->created_at); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Atualizado em</label>
				<input type="text" name="updated_at" value="<?php echo e($p->updated_at); ?>" class="form-control">
			</div>
			<button type="submit" class="btn btn-primary btn-block">Envia</button>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>