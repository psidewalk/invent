<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="container-fluid">

			<br/>
			<h2>Novo Doc do Processo : <?php echo e($codVai); ?> <?php echo e($nome); ?></h2>

			<?php if(!empty($pessoas)): ?>
				<form action = "<?php echo e(url('saveDoc')); ?>" method="post">
			<?php else: ?>
			    <form action = "<?php echo e(url('saveDocdeProc')); ?>" method="post">
			<?php endif; ?>
			
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
					
				<div class="form-group">
					<input type="hidden" name="processo_id" value="<?php echo e($idVai); ?>" class="form-control">
				</div>
				</br>
				<div class="form-group">
					<label>Código do Doc</label>
					<input name="codigo" class="form-control">
				</div>
				<div class="form-group">
					<label>Titulo do Doc</label>
					<input name="titulo" class="form-control">
				</div>
				<div class="form-group">
					<label>Data de Entrada</label>
					<input name="dtEntrada" class="form-control calend">
				</div>
				<div class="form-group">
					<label>Data da Entrega</label>
					<input name="dtEntrega" class="form-control calend">
				</div>
				<div class="form-group">
					<label>Custo do Doc</label>
					<input name="custo" class="form-control">
				</div>
				<div class="form-group">
					<label>Observações</label>
					<input name="texto" class="form-control">
				</div>
                </br>
				<?php if(!empty($pessoas)): ?>
					<div class="form-group">
						<select name="idPess">
							<?php $__currentLoopData = $pessoas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option class="form-control" value="<?php echo $p->id; ?>"><?php echo $p->nome; ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				<?php endif; ?>
                </br>
				<button type="submit" class="btn btn-primary btn-block">Envia</button>
				
			</form>

		</div>
	</div>
	
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>