<?php $__env->startSection('content'); ?>

<!--
<div class="container-fluid">
    <div class="navbar-right">
        <form class="form-search form form-inline" method="get" action="/pess/pesqdata">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="pesquisar" placeholder= "Ano-Mes-Dia" class="form-control calend">
            <input type="submit" value="Selecionar" class="btn btn-danger">
        </form>
    </div>
    <div class="navbar-left">
        <form class="form-search form form-inline" method="get" action="/pess/calcdif">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="dtini"   placeholder= "A-M-D inicial" class="form-control calend">
            <input type="text" name="dtfim"   placeholder= "A-M-D final" class="form-control calend">
            <input type="text" name="tipo"    placeholder="" class="form-control">
            <input type="submit" value="Calcular" class="btn btn-danger">
        </form>
            <?php if(!empty($pesif)): ?>
                <?php echo e($pesif); ?>

            <?php endif; ?>
        </form>
    </div>
</div>
-->

<?php if(empty($pessoas)): ?>

<div class="alert alert-danger">
    Voce ainda não cadastrou nenhuma Pessoa
</div>

<?php else: ?>
<br/>
<table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
    <thead>
    <!-- <th style="text-align: center"><a href="#">Código</a></th> por enquanto, fora--> 
    <th><a href="#">Docs</a></th>
    <th><a href="#">Nome da Pessoa</a></th>
    <th><a href="#">CPF</a></th>
    <th>Data Nasc</th>
    <th>Identidade</th>
    <th>Nome do Pai</th>
    <th>Nome da Mãe</th>
    <th>N.Benef.INSS</th>
    <th>N.Benef.PrvBnrj</th>
    <th>Data Falec.</th>
    <th>Observações</th>
    <th>Editar</th>
    <th>Excluir</th>
</thead>
<tbody>
    <?php $__currentLoopData = $pessoas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    <!-- o foreach do blade  -->
    <tr align="center">
        <td><a href="<?php echo e(url('listaPessDocs',$p->id)); ?>"><span class="glyphicon glyphicon-trash"></span></a></td>
        <!-- <td><?php echo e($p->codigo); ?></td> por enquanto está fora -->
        <td><?php echo e($p->nome); ?></td>
        <td><?php echo e($p->cpf); ?></td>
        <td><?php echo e($p->dtNasc); ?></td>
        <td><?php echo e($p->ident); ?></td>
        <td><?php echo e($p->nome_pai); ?></td>
        <td><?php echo e($p->nome_mae); ?></td>
        <td><?php echo e($p->benefINSS); ?></td>
        <td><?php echo e($p->benefPrvBan); ?></td>
        <td><?php echo e($p->dtFalec); ?></td>
        <td><?php echo e($p->texto); ?></td>
        <td><a href="<?php echo e(url('editaPess',$p->id)); ?>"><span class="glyphicon glyphicon-search"></a></td>
        <td><a href="<?php echo e(url('excluiPess',$p->id)); ?>"><span class="glyphicon glyphicon-trash"></span></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!--
    -->
</table>
    <!-- <a class="btn btn-danger" id="butListDocs" href="<?php echo e(url('criaPess')); ?>" role="button">Nova Pessoa</a> -->
<?php endif; ?>
<!-- <div class="alert alert-success">
    <strong>Operação bem-sucedida !</strong>
</div>
-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>