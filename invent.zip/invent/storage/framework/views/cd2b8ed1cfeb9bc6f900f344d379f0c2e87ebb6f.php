<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="container-fluid">
		<br/>
		<h2>Editando o documento <?php echo e($d->id); ?> do Inventário de <?php echo e($d->processo->nome); ?></h2>
		<br/>
		<form action="<?php echo e(url('updateDoc',$d->id)); ?>" method="post">

			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

			<div class="form-group">
				<label>Código</label>
				<input type="text" name="codigo" value="<?php echo e($d->codigo); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Titulo</label>
				<input type="text" name="titulo" value="<?php echo e($d->titulo); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Dt entrada</label>
				<input type="text" name="dtEntrada" value="<?php echo e($d->dtEntrada); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Dt entrega</label>
				<input type="text" name="dtEntrega" value="<?php echo e($d->dtEntrega); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Custo</label>
				<input type="text" name="custo" value="<?php echo e($d->custo); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Texto</label>
				<input type="text" name="texto" value="<?php echo e($d->texto); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Criado em</label>
				<input type="text" name="created_at" value="<?php echo e($d->created_at); ?>" class="form-control">
			</div>
			<div class="form-group">
				<label>Atualizado em</label>
				<input type="text" name="updated_at" value="<?php echo e($d->updated_at); ?>" class="form-control">
			</div>
			<button type="submit" class="btn btn-primary btn-block">Envia</button>

		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>