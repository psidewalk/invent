<?php $__env->startSection('content'); ?>

<!--
<div class="container-fluid">
    <div class="navbar-right">
        <form class="form-search form form-inline" method="get" action="/pess/pesqdata">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="pesquisar" placeholder= "Ano-Mes-Dia" class="form-control calend">
            <input type="submit" value="Selecionar" class="btn btn-danger">
        </form>
    </div>
    <div class="navbar-left">
        <form class="form-search form form-inline" method="get" action="/pess/calcdif">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="dtini"   placeholder= "A-M-D inicial" class="form-control calend">
            <input type="text" name="dtfim"   placeholder= "A-M-D final" class="form-control calend">
            <input type="text" name="tipo"    placeholder="" class="form-control">
            <input type="submit" value="Calcular" class="btn btn-danger">
        </form>
            <?php if(!empty($pesif)): ?>
                <?php echo e($pesif); ?>

            <?php endif; ?>
        </form>
    </div>
</div>
-->

<?php if(empty($pessoas)): ?>

<div class="alert alert-danger">
    Voce ainda não cadastrou nenhuma Pessoa
</div>

<?php else: ?>
<br/>
<table class="table table-striped table-bordered table-hover" style="font-size: 1.2em ; font-weight:bold">
    <thead>
    <th style="text-align: center"><a href="#">Código</a></th>
    <th style="text-align: center"><a href="#">Nome da Pessoa</a></th>
    <th style="text-align: center"><a href="#">CPF</a></th>
    <th style="text-align: center">Data Nasc</th>
    <th style="text-align: center">Identidade</th>
    <th style="text-align: center">Nome do Pai</th>
    <th style="text-align: center">Nome da Mãe</th>
    <th style="text-align: center">N.Benef.INSS</th>
    <th style="text-align: center">N.Benef.PrvBnrj</th>
    <th style="text-align: center">Data Falec.</th>
    <th style="text-align: center">Observações</th>
    <th style="text-align: center">Editar</th>
    <th style="text-align: center">Excluir</th>
</thead>
<tbody>
    <?php $__currentLoopData = $pessoas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pessoa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    <!-- o foreach do blade  -->
    <tr align="center">
        <td><?php echo e($pessoa->codigo); ?></td>
        <td><?php echo e($pessoa->nome); ?></td>
        <td><?php echo e($pessoa->cpf); ?></td>
        <td><?php echo e($pessoa->dtNasc); ?></td>
        <td><?php echo e($pessoa->ident); ?></td>
        <td><?php echo e($pessoa->nome_pai); ?></td>
        <td><?php echo e($pessoa->nome_mae); ?></td>
        <td><?php echo e($pessoa->benefINSS); ?></td>
        <td><?php echo e($pessoa->benefPrvBan); ?></td>
        <td><?php echo e($pessoa->dtFalec); ?></td>
        <td><?php echo e($pessoa->texto); ?></td>
        <td><a href="/pessoa/edit/<?php echo e($pessoa->id); ?>"><span class="glyphicon glyphicon-search"></a></td>
        <td><a href="/pessoa/destroy/<?php echo e($pessoa->id); ?>"><span class="glyphicon glyphicon-trash"></span></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!--
    -->
</table>
    <a class="btn btn-danger" id="butListDocs" href="/createPess" role="button">Nova Pessoa</a>
<?php endif; ?>
<!-- <div class="alert alert-success">
    <strong>Operação bem-sucedida !</strong>
</div>
-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>