<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDocsTable extends Migration
{
     public function up()
    {
        Schema::create('docs', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('processo_id')->unsigned();
            $table->foreign('processo_id')->references('id')->on('processos');
            $table->string('codigo','20')->unique();
            $table->string('titulo',100);
            $table->dateTimeTz('dtEntrada',"yyyy-mm-dd H:i:s");
            $table->dateTimeTz('dtEntrega',"yyyy-mm-dd H:i:s");
            $table->decimal('custo',7,2);
            $table->text('texto');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('docs');
    }
}
