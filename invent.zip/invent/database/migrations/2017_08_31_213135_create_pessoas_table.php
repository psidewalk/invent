<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePessoasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pessoas', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('codigo',false,true)->length(1);
            $table->string('nome',50);
            $table->string('cpf',12)->unique();
            $table->date('dtNasc',"yyyy-mm-dd");
            $table->string('ident',20);
            $table->string('nome_pai',50);
            $table->string('nome_mae',50);
            $table->string('benefINSS',20);
            $table->string('benefPrvBan',20);
            $table->date('dtFalec',"yyyy-mm-dd");
            $table->text('texto');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pessoas');
    }
}
