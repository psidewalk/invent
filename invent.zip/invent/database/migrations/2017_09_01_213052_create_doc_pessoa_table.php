<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDocPessoaTable extends Migration
{
    public function up()
    {
        Schema::create('doc_pessoa', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('doc_id')->unsigned();
            $table->foreign('doc_id')->references('id')->on('docs');
            $table->integer('pessoa_id')->unsigned();
            $table->foreign('pessoa_id')->references('id')->on('pessoas');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('doc_pessoa');
    }
}
